/**
 ****************************************************************************************************
 * @file        main.c
 * @author      TGU_LINBO
 * @version     V1.0
 * @date        2023-02-06
 * @GPIO        CS PB12 SCK PB13 MISO PB14 MOSI PB15
 * @notice      ����ģ��SPI����ģʽ0����SCK���е�ƽΪ�͵�ƽ �����ؽ������ݲɼ� 
 ****************************************************************************************************
 **/

#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/LCD/lcd.h"
#include <string.h>
#include "spi.h"
#include "w25q128.h"
#include "key.h"
int main(void)
{
    uint8_t x = 0;
    uint8_t lcd_id[12];
    uint32_t addres = 0x100000,D_len=0;                         /* д��ĵ�ַ */
	  uint8_t Data[10] = {0X0,0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08,0X09}; /* д������� */
    uint8_t BMP_data[]={
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,
      0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,0XE7,0X39,      
                     };
    D_len=sizeof(BMP_data);
    //uint8_t Data[7] = {0X0a,0X0b};                                /* д������� */
    uint8_t R_Data[]={0};                               /* ��ʼ��HAL�� */
    uint8_t key;
    uint16_t id;        
    HAL_Init();                                         /* ��ʼ��HAL�� */
    sys_stm32_clock_init(RCC_PLL_MUL9);                 /* ����ʱ��, 72Mhz */
    delay_init(72);                                     /* ��ʱ��ʼ�� */
    usart_init(115200);                                 /* ���ڳ�ʼ��Ϊ115200 */
    led_init();                                         /* ��ʼ��LED */
    lcd_init();                                         /* ��ʼ��LCD */
	  spi_init();                                         /* ��ʼ��I2C */
    key_init();                                         /* ��ʼ������ */
    g_point_color = BLACK;
    sprintf((char *)lcd_id, "LCD ID:%04X", lcddev.id);  /* ��LCD ID��ӡ��lcd_id���� */
    lcd_clear(WHITE);
    id = W25_read_ID();
    W25_erase_sector(addres);
    printf("W25Q128_ID:0x%hx\r\n",id);
    
    /*******һ�ֽڶ�д����********/                
//    W25_write_page(0x123456,0x1f);
//    W25_write_page(0x123457,0x1f);
//    R_Data[0]=W25_read_data(0x123456);



    /****������д�ֽ����ݲ���****/                

//    printf("д�������Ϊ��\r\n");
//    for(int p=0;p<D_len;p++)
//    {
//     printf("%hx ",Data[p]);
//    }
//    printf("\r\n");
//    W25_write_data_con(addres,Data,D_len);
////    R_Data[0]=W25_read_data(addres);
////    printf("���������Ϊ��\r\n");
////    printf("%d ",R_Data[0]);
//    W25_read_data_con(addres,R_Data,D_len);
//    
//    printf("���������Ϊ��\r\n");
//    for(int p=0;p<D_len;p++)
//    {
//     printf("%hx ",R_Data[p]);
//    }
//    printf("\r\n");

    /****���ֽڶ�д�ֽ����ݲ���****/                
//    printf("д�������Ϊ��\r\n");
//    for(int p=0;p<D_len;p++)
//    {
//     printf("%hx ",BMP_data[p]);
//    }
//    W25_write_data_auto_page(addres,BMP_data,D_len);    
//    printf("\r\n");
//    W25_erase_ALLchip();
//    W25_read_data_con(addres,R_Data,D_len);
//    
//    printf("���������Ϊ��\r\n");
//    for(int p=0;p<D_len;p++)
//    {
//     printf("%hx ",R_Data[p]);
//    }
//    printf("\r\n");
    
    
    /****���ֽڶ�д�ֽ����ݲ���****/                
    printf("д�������Ϊ��\r\n");
    for(int p=0;p<D_len;p++)
    {
     printf("%hx ",BMP_data[p]);
    }
    W25_write(addres,BMP_data,D_len);   
    printf("\r\n");
    W25_read_data_con(addres,R_Data,D_len);
    printf("���������Ϊ��\r\n");
    for(int p=0;p<D_len;p++)
    {
     printf("%hx ",R_Data[p]);
    }
    printf("\r\n");    
    
    
    
    
    while (1)
    {	
      key = key_scan(0);
	    //lcd_show_num(0,30,id,10,24,BLACK);
      
    }                         
}


