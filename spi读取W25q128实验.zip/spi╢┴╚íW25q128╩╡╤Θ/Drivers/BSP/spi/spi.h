/**
 ****************************************************************************************************
 * @file        spi.h
 * @author      TGU_LINBO
 * @version     V1.0
 * @date        2023-02-06
 ****************************************************************************************************
 **/
#ifndef __SPI_H
#define __SPI_H
#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LCD/lcd.h"
/********���ź궨��********/
#define SCK  GPIO_PIN_13  //W25Q128 SCK����
#define MISO GPIO_PIN_14  //W25Q128 SO����
#define MOSI GPIO_PIN_15  //W25Q128 SI����
#define CS GPIO_PIN_12    //W25Q128 CS����
#define SPI_GPIO_CLK_ENABLE() do{ __HAL_RCC_GPIOB_CLK_ENABLE(); }while(0)   /* ����IO��ʱ��ʹ�� */
#define SPI_GPIO_PORT GPIOB

/* 24C02�˿ڶ��� */
#define _SCK(x)   do{ x ? \
                      HAL_GPIO_WritePin(SPI_GPIO_PORT,SCK,GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(SPI_GPIO_PORT,SCK,GPIO_PIN_RESET); \
                  }while(0)      /* SCK��ת */
#define _MOSI(x)   do{ x ? \
                      HAL_GPIO_WritePin(SPI_GPIO_PORT,MOSI,GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(SPI_GPIO_PORT,MOSI,GPIO_PIN_RESET); \
                  }while(0)      /* MOSI��ת */
#define _CS(x)   do{ x ? \
                      HAL_GPIO_WritePin(SPI_GPIO_PORT,CS,GPIO_PIN_SET) : \
                      HAL_GPIO_WritePin(SPI_GPIO_PORT,CS,GPIO_PIN_RESET); \
                  }while(0)      /* MOSI��ת */
#define _MISO_READ     HAL_GPIO_ReadPin(SPI_GPIO_PORT,MISO) /* ��ȡMISO */
/********��������********/
uint8_t spi_read_byte(void);              //SPIд����
void spi_write_byte(uint8_t data);        //SPI������
uint8_t spi_write_read_byte(uint8_t data);//SPIͬʱ��д����
void spi_init(void);                      //SPI��ʼ��                  
#endif