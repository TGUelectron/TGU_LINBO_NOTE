/**
 ****************************************************************************************************
 * @file        w25q128.h
 * @author      TGU_LINBO
 * @version     V1.0
 * @date        2023-02-06
 * @brief       w25q128 SPI ��д����
 * @GPIO        CS PB12 SCK PB13 MISO PB14 MOSI PB15 
 ****************************************************************************************************
 **/
 #ifndef __W25Q128_H
 #define __W25Q128_H
 #include "spi.h"
 /********��������********/
 uint8_t W25_read_sr1();
 uint8_t W25_read_data(uint32_t addr);
 void W25_erase_sector(uint32_t addr);
 void W25_erase_ALLchip(void);
 void W25_write_page(uint32_t addr,uint8_t data);
 uint16_t W25_read_ID(void);
 void  W25_read_data_con(uint32_t addr,uint8_t *buf,uint16_t datalen);
 void  W25_write_data_con(uint32_t addr,uint8_t *buf,uint16_t datalen);
 void  W25_write_data_auto_page(uint32_t addr,uint8_t *buf,uint16_t datalen);
 void  W25_write(uint32_t addr,uint8_t *pbuf, uint16_t datalen);
 #endif